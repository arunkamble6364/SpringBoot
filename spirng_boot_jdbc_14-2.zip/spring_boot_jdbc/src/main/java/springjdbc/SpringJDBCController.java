package springjdbc;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
public class SpringJDBCController {
    @Autowired
	JdbcTemplate jdbc;
	
	@RequestMapping("/")
	public String test()
	{
		return "type correct url";
	}
	@RequestMapping("/addstudent")
	public String adst()
	{
		jdbc.execute("insert into student (rollno,sname,classname) values (111,'amit kumar sharma','mba');");
		return "data saved";
	}
	
}
