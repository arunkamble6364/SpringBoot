package spring_boot_2_22;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RSTController {
	@Autowired
	JdbcTemplate objJDBC;
@RequestMapping("/msg")
	public String msg()
	{		
		return "hello world";
	}
@RequestMapping("/test")
public String show()
{		
	return "you are seeing this page ";
}
@RequestMapping("/addemp")
public String addRecordEmp(@RequestParam String name,@RequestParam String add,@RequestParam float salary)
{
  String msg="";
  String query="insert into employee (ename,address,sal) values('"+name+"','"+add+"',"+salary+")";
  if(objJDBC.update(query)==1)
	    msg="record is inserted";
  else
    msg="try again";
  
  return msg;
}

}
