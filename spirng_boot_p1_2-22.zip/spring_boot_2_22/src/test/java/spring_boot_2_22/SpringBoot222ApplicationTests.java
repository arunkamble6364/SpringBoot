package spring_boot_2_22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot222ApplicationTests {

	@Test
	void contextLoads() {
	}

}
