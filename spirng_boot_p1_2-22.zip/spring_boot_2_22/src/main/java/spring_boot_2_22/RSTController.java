package spring_boot_2_22;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RSTController {
@RequestMapping("/msg")
	public String msg()
	{		
		return "hello world";
	}
@RequestMapping("/test")
public String show()
{		
	return "you are seeing this page ";
}
}
